<h1>Main page</h1>
<h3>Welcome, <?php echo $name ?></h3>