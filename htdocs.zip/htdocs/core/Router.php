<?php 
    //use general namespace
    namespace app\core;

    /**
     * @package app\core
     * 
     * @param app\core\Request $request
     * @param app\core\Response $response
     */

    //class that include all routes
    class Router {
        //var-request
        public Request $request;
        //var-response
        public Response $response;
        //array all routes
        protected array $routes = [];

        public function __construct(Request $request, Response $response)
        {
            $this->request = $request;
            $this->response = $response;
        }

        //get method routes
        public function get($path, $callback) {
            $this->routes['get'][$path] = $callback;
        }
        //post method routes
        public function post($path, $callback) {
            $this->routes['post'][$path] = $callback;
        }
        
        public function resolve() {
            $path = $this->request->getPath();
            $method = $this->request->method();
            $callback = $this->routes[$method][$path] ?? false;
            //var_dump($this->routes[$method][$path]);
            

            if ($callback === false) {
                $this->response->setStatusCode(404);
                return $this->renderView("_404");
            }
            if(is_string($callback)) {
                return $this->renderView($callback);
            }
            if(is_array($callback)) {
                Application::$app->controller = new $callback[0];
                $callback[0] = Application::$app->controller;
            }

            echo call_user_func($callback, $this->request, $this->response);
        }

        public function renderView($view, $params = []) {
            $layoutContent = $this->layoutContent();
            $viewContent = $this->renderOnlyView($view, $params);
            //var_dump($viewContent);
            return str_replace('{{content}}', $viewContent, $layoutContent);
        }
        public function renderContent($viewContent) {
            $layoutContent = $this->layoutContent();
            return str_replace('{{content}}', $viewContent, $layoutContent);
        }

        protected function layoutContent() {
            $layout = Application::$app->controller->layout;
            ob_start();
            include_once Application::$ROOT_DIR."/views/layouts/$layout.php";
            return ob_get_clean();
        }

        protected function renderOnlyView($view, $params) {
            foreach ($params as $key => $value) {
                $$key = $value;
            }
            ob_start();
            include_once Application::$ROOT_DIR."/views/$view.php";
            return ob_get_clean();
        }
    }
?>