<?php

/** @var $exception \Exception */

?>

<h3><?php echo $exception->getCode() ?> - <?php echo $exception->getMessage() ?></h3>