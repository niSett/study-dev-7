<?php
/** @var $this \app\core\View */
$this->title = 'Profile'; 

?>

<h1>Profile</h1>